import { useEffect, useState, useCallback, useRef } from "react"

type Screen = "home" | "specialty" | "location" | "date" | "time" | "confirm" | "success" | "cancel" | "appointment" | "staff"

const navItems = ["Inicio", "Nueva atención", "Citas", "Configuración"]
const specialties = ["Medicina general", "Odontología", "Pediatría", "Ginecología", "Medicina interna", "Otra especialidad"]
const times = ["8:00 a. m.", "9:30 a. m.", "11:00 a. m.", "2:00 p. m.", "3:30 p. m."]

function Icon({ children }: { children: string }) { return <span aria-hidden="true" className="icon">{children}</span> }

function Button({ children, onClick, kind = "primary", className = "" }: { children: React.ReactNode; onClick?: () => void; kind?: "primary" | "secondary" | "danger" | "quiet"; className?: string }) {
  return <button onClick={onClick} className={`button button-${kind} ${className}`}>{children}</button>
}

function VideoCard({ label, camera = false, playing, setPlaying }: { label: string; camera?: boolean; playing?: boolean; setPlaying?: (v: boolean) => void }) {
  const showSpecialtyBoard = !camera && /especialidad/i.test(label)
  return <div className={`video-card ${camera ? "video-camera" : ""}`}>
    {showSpecialtyBoard && <div className="specialty-board"><strong>En señas: escoge qué número</strong><span>¿Qué especialidad necesita?</span><div><b>1</b> 🩺 Medicina general</div><div><b>2</b> 🦷 Odontología</div><div><b>3</b> 🧸 Pediatría</div></div>}
    <div className="video-noise" />
    <div className="person person-head" /><div className="person person-body" /><div className="person person-arm arm-a" /><div className="person person-arm arm-b" />
    <div className="video-top"><span className={camera ? "live" : "video-tag"}>{camera ? "● Cámara activa" : "LSC"}</span><span className="video-time">{playing ? "00:08" : "00:00"}</span></div>
    {camera && <div className="signing-frame"><span>Ubique sus manos dentro del área</span></div>}
    <div className="video-caption">{camera ? "Vista previa de la cámara" : `Video LSC: ${label}`}</div>
    {!camera && <div className="video-controls"><button onClick={() => setPlaying?.(!playing)} aria-label="Reproducir o pausar">{playing ? "Ⅱ" : "▶"}</button><button onClick={() => setPlaying?.(false)} aria-label="Repetir">↻</button><button className="sub">CC Subtítulos</button></div>}
  </div>
}

function Stepper({ screen }: { screen: Screen }) {
  const steps = ["Especialidad", "Sede", "Fecha", "Horario", "Confirmar"]
  const active = ({ home: -1, specialty: 0, location: 1, date: 2, time: 3, confirm: 4, success: 4, cancel: -1, appointment: -1, staff: -1 } satisfies Record<Screen, number>)[screen]
  if (active < 0) return null
  return <div className="stepper">{steps.map((s, i) => <div key={s} className={`step ${i <= active ? "done" : ""}`}><span>{i < active ? "✓" : i + 1}</span><em>{s}</em></div>)}</div>
}

function Conversation({ screen, setScreen }: { screen: Screen; setScreen: (s: Screen) => void }) {
  const [playing, setPlaying] = useState(false)
  const videoLabels: Record<Screen, string> = { home: "confirmación de servicio detectado", specialty: "seleccione especialidad con un número", location: "seleccione sede con un número", date: "seleccione fecha disponible", time: "seleccione horario con un número", confirm: "confirmación de datos", success: "cita confirmada", cancel: "confirmación de cancelación", appointment: "información de próxima cita", staff: "atención transferida" }
  const messages = screen === "staff" ? [
    ["sys", "Atención transferida a Recepción", "10:35"], ["staff", "Hola, soy Valentina. Estoy aquí para ayudarte.", "10:35"],
  ] : [["bot", "¡Hola, Laura! Bienvenida a InLSC.", "10:31"], ["user", "Deseo solicitar una cita médica", "10:32"], ["bot", "Entendí: asignar una cita. Seleccione una opción para continuar.", "10:32"]]
  const quick = screen === "home" ? [["Continuar con asignación de cita", "specialty"]] as const : [["Cancelar una cita", "cancel"], ["Consultar mi cita", "appointment"], ["Consultar especialidad", "specialty"], ["Consultar horarios", "date"], ["Información de pagos", "home"]] as const
  return <section className="assistant-panel"><div className="panel-title"><div><p className="eyebrow">ASISTENTE VIRTUAL</p><h2>Asistente de atención</h2></div><span className="online">En línea</span></div>
    <VideoCard label={videoLabels[screen]} playing={playing} setPlaying={setPlaying} />
    <p className="video-instruction">{screen === "success" ? "Su cita ha sido confirmada." : "El video guía a la persona para responder mediante señas numéricas."}</p>
    <div className="messages">{messages.map(([type, text, time], i) => <div className={`message ${type}`} key={i}><div className="message-label">{type === "bot" ? "✦ Asistente" : type === "user" ? "LSC reconocida · ✓" : type === "staff" ? "● Funcionaria" : "Sistema"}<time>{time}</time></div><p>{text}</p></div>)}</div>
    <p className="admin-controls">Controles del funcionario · Seleccione el siguiente video LSC</p><div className={`quick-actions ${screen === "home" ? "single-service" : ""}`}>{quick.map(([label, target]) => <button key={label} onClick={() => setScreen(target)}>{label}<span>→</span></button>)}<button className="staff-action" onClick={() => setScreen("staff")}><Icon>♧</Icon> Hablar con un funcionario</button></div>
  </section>
}

function WelcomeAssistant() {
  const [playing, setPlaying] = useState(true)
  return <section className="assistant-panel welcome-assistant"><div className="panel-title"><div><p className="eyebrow">ASISTENTE LSC</p><h2>Bienvenida</h2></div><span className="online">Listo para atender</span></div>
    <VideoCard label="bienvenida" playing={playing} setPlaying={setPlaying} />
    <div className="welcome-message"><span className="quote-mark">"</span><p>Bienvenida a la IPS Virrey Solís. <strong>Estamos listos para atenderle.</strong></p></div>
    <div className="waiting-state"><i className="pulse-dot" /><div><strong>Esperando una expresión en LSC</strong><span>Realice la seña frente a la cámara.</span></div></div>
    <div className="recognition-progress"><i /><span>Reconociendo seña…</span></div><p className="access-note">La sesión comienza sin guardar datos.</p>
  </section>
}

function IntakeSession({ onDetected }: { onDetected: () => void }) {
  useEffect(() => { const timer = window.setTimeout(onDetected, 3000); return () => window.clearTimeout(timer) }, [onDetected])
  return <main className="intake-session"><section className="intake-camera"><div className="intake-top"><div><span className="eyebrow">INLSC · NUEVA ATENCIÓN</span><h1>Realice su seña con tranquilidad</h1><p>La cámara está activa y lista para identificar el trámite que necesita.</p></div><span className="intake-live">● Cámara activa</span></div><VideoCard label="vista de cámara" camera /><div className="camera-guidance"><span className="guide-icon">✋</span><div><strong>Responda únicamente con la seña del número</strong><p>El sistema detectará la opción y la traducirá para el funcionario.</p></div></div></section><WelcomeAssistant /></main>
}

function FloatingLauncher({ onStart }: { onStart: () => void }) {
  return <main className="launcher-canvas"><div className="launcher-backdrop"><div className="placeholder-top"><span className="virrey-logo">VIRREY SOLÍS <small>IPS</small></span><span>Portal de atención · Sede Olaya</span></div><div className="placeholder-main"><p>IPS VIRREY SOLÍS · OLAYA</p><h1>Calidad e innovación<br />para mejorar tu salud.</h1><div className="portal-options"><span>Solicite o consulte sus citas</span><span>Información de servicios</span><span>Canales de atención</span></div></div></div><section className="floating-launcher"><div className="launcher-top"><div className="brand-mark">I</div><div><strong>InLSC</strong><span>Asistente en LSC salud</span></div><i className="launcher-online">●</i></div><div className="launcher-copy"><span className="eyebrow">ATENCIÓN INCLUSIVA</span><h1>¿Necesita ayuda?</h1><p>Inicie una atención administrativa en Lengua de Señas Colombiana.</p></div><button className="launcher-start" onClick={onStart}>Iniciar atención <span>→</span></button><p className="privacy-note">Sesión temporal · No se guarda información automáticamente.</p><button className="launcher-help">? Ayuda y accesibilidad</button></section></main>
}

// ─── Flow Data ────────────────────────────────────────────────────────────────

type StepKind = "video" | "specialty" | "date" | "cita"

interface FlowStep {
  label: string
  video: string
  message: string
  kind: StepKind
  action: string
}

interface FlowPath {
  id: string
  name: string
  icon: string
  color: string
  bg: string
  steps: FlowStep[]
}

const FLOW_PATHS: FlowPath[] = [
  {
    id: "asignacion", name: "Asignacion de citas", icon: "📋", color: "#145da0", bg: "#e8f2fd",
    steps: [
      { label: "Saludo", video: "Buen dia", message: "Iniciando atencion · Video de saludo enviado.", kind: "video", action: "Continuar" },
      { label: "Solicitud", video: "Cual es su solicitud", message: "Preguntando por solicitud al senante.", kind: "video", action: "Detectado: asignacion" },
      { label: "Documento", video: "Entregar documento de identidad", message: "Solicitando documento de identidad.", kind: "video", action: "Documento verificado" },
      { label: "Especialidad", video: "Que especialidad necesita", message: "Seleccione la especialidad para el senante:", kind: "specialty", action: "" },
      { label: "Autorizacion", video: "Autorizacion para agendar cita", message: "Solicitando autorizacion de agendamiento.", kind: "video", action: "Continuar" },
      { label: "Disponibilidad", video: "Disponibilidad · Escoja un numero", message: "Seleccione fechas y horarios disponibles:", kind: "date", action: "" },
      { label: "Confirmacion", video: "Cita confirmada · Que tenga buen dia", message: "Cita asignada correctamente.", kind: "video", action: "Finalizar atencion" },
    ],
  },
  {
    id: "cancelacion", name: "Cancelacion de citas", icon: "❌", color: "#c53d3d", bg: "#fdeaea",
    steps: [
      { label: "Saludo", video: "Buen dia", message: "Iniciando atencion · Video de saludo enviado.", kind: "video", action: "Continuar" },
      { label: "Solicitud", video: "Cual es su solicitud", message: "Preguntando por solicitud al senante.", kind: "video", action: "Detectado: cancelacion" },
      { label: "Cancelacion", video: "Cancelacion de cita", message: "Confirmando intencion de cancelar.", kind: "video", action: "Continuar" },
      { label: "Documento", video: "Entregar documento de identidad", message: "Solicitando documento de identidad.", kind: "video", action: "Documento verificado" },
      { label: "Que cita cancelar", video: "Que cita requiere cancelar", message: "Seleccione la cita a cancelar:", kind: "cita", action: "" },
      { label: "Cancelada", video: "Su cita ha sido cancelada", message: "Cita cancelada correctamente.", kind: "video", action: "Continuar" },
      { label: "Despedida", video: "Que tenga buen dia", message: "Atencion finalizada.", kind: "video", action: "Finalizar atencion" },
    ],
  },
  {
    id: "facturacion", name: "Facturacion de citas", icon: "💲", color: "#2d7a3a", bg: "#e6f4ea",
    steps: [
      { label: "Saludo", video: "Buen dia", message: "Iniciando atencion · Video de saludo enviado.", kind: "video", action: "Continuar" },
      { label: "Solicitud", video: "Cual es su solicitud", message: "Preguntando por solicitud al senante.", kind: "video", action: "Detectado: facturacion" },
      { label: "Documento", video: "Entregar documento de identidad", message: "Solicitando documento de identidad.", kind: "video", action: "Documento verificado" },
      { label: "Orden medica", video: "Orden medica", message: "Verificando orden medica del paciente.", kind: "video", action: "Verificada" },
      { label: "Valor", video: "Valor a pagar", message: "Informando valor a cancelar.", kind: "video", action: "Informado" },
      { label: "Solo efectivo", video: "Solo se recibe pago en efectivo", message: "Solo se recibe pago en efectivo.", kind: "video", action: "Entendido" },
      { label: "Recibo", video: "Recibo entregado", message: "Recibo entregado al paciente.", kind: "video", action: "Continuar" },
      { label: "Sala espera", video: "Espere en la sala consultorio", message: "Indicando sala de espera al senante.", kind: "video", action: "Continuar" },
      { label: "Con gusto", video: "Con gusto · Que tenga buen dia", message: "Atencion finalizada con exito.", kind: "video", action: "Finalizar atencion" },
    ],
  },
]

const SPECIALTIES_LIST = [
  { name: "Medicina general", icon: "🩺" },
  { name: "Odontologia", icon: "🦷" },
  { name: "Pediatria", icon: "🧸" },
  { name: "Ginecologia", icon: "👩‍⚕️" },
  { name: "Psicologia", icon: "🧠" },
  { name: "Nutricion", icon: "🥗" },
  { name: "Medicina interna", icon: "🫀" },
]

const CITAS_MOCK = [
  { specialty: "Medicina general", doctor: "Dr. Rojas", date: "Mie 18 Sep", time: "9:30 a.m.", icon: "🩺" },
  { specialty: "Odontologia", doctor: "Dra. Moreno", date: "Vie 20 Sep", time: "2:00 p.m.", icon: "🦷" },
  { specialty: "Pediatria", doctor: "Dr. Castillo", date: "Lun 23 Sep", time: "10:00 a.m.", icon: "🧸" },
]

// ─── Date/Time picker ─────────────────────────────────────────────────────────

const MONTHS = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"]
const MONTH_SHORT = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"]
const DAY_NAMES = ["L","M","M","J","V","S","D"]
const HOURS = ["6","7","8","9","10","11","12","1","2","3","4","5"]
const MINUTES = ["00","15","30","45"]

interface TimeSlot { day: number; month: number; year: number; hour: string; minute: string; ampm: "a.m."|"p.m." }

function daysInMonth(month: number, year: number) { return new Date(year, month + 1, 0).getDate() }
function dayOfWeek(day: number, month: number, year: number) { let d = new Date(year, month, day).getDay(); return d === 0 ? 6 : d - 1 }

function DateTimePicker({ onSendSlots }: { onSendSlots: (slots: TimeSlot[]) => void }) {
  const today = new Date()
  const [viewMonth, setViewMonth] = useState(today.getMonth())
  const [viewYear, setViewYear] = useState(today.getFullYear())
  const [selectedDay, setSelectedDay] = useState<number | null>(null)
  const [selHour, setSelHour] = useState("9")
  const [selMin, setSelMin] = useState("00")
  const [selAmpm, setSelAmpm] = useState<"a.m."|"p.m.">("a.m.")
  const [slots, setSlots] = useState<TimeSlot[]>([])

  const prevMonth = () => { if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1) } else setViewMonth(m => m - 1); setSelectedDay(null) }
  const nextMonth = () => { if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1) } else setViewMonth(m => m + 1); setSelectedDay(null) }

  const addSlot = useCallback(() => {
    if (!selectedDay) return
    const slot: TimeSlot = { day: selectedDay, month: viewMonth, year: viewYear, hour: selHour, minute: selMin, ampm: selAmpm }
    const key = (s: TimeSlot) => `${s.day}-${s.month}-${s.year}-${s.hour}-${s.minute}-${s.ampm}`
    setSlots(prev => prev.find(s => key(s) === key(slot)) ? prev : [...prev, slot].slice(0, 6))
  }, [selectedDay, viewMonth, viewYear, selHour, selMin, selAmpm])

  const removeSlot = (i: number) => setSlots(prev => prev.filter((_, idx) => idx !== i))

  const formatSlot = (s: TimeSlot) => {
    const d = new Date(s.year, s.month, s.day)
    const dayName = ["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"][d.getDay()]
    return `${dayName} ${s.day} ${MONTH_SHORT[s.month]} · ${s.hour}:${s.minute} ${s.ampm}`
  }

  const totalDays = daysInMonth(viewMonth, viewYear)
  const offset = dayOfWeek(1, viewMonth, viewYear)
  const cells: (number | null)[] = [...Array(offset).fill(null), ...Array.from({length: totalDays}, (_, i) => i + 1)]

  return (
    <div className="dt-picker">
      <div className="dt-section">
        <div className="dt-month-nav">
          <button onClick={prevMonth} className="dt-nav-btn">‹</button>
          <span className="dt-month-label">{MONTHS[viewMonth]} {viewYear}</span>
          <button onClick={nextMonth} className="dt-nav-btn">›</button>
        </div>
        <div className="dt-day-names">{DAY_NAMES.map((d,i) => <span key={i}>{d}</span>)}</div>
        <div className="dt-day-grid">
          {cells.map((d, i) => d === null
            ? <span key={`e${i}`} className="dt-cell-empty" />
            : <button key={d} onClick={() => setSelectedDay(d)} className={`dt-cell${selectedDay === d ? " dt-selected" : ""}`}>{d}</button>
          )}
        </div>
      </div>

      <div className="dt-section dt-time-section">
        <p className="dt-label">Hora</p>
        <div className="dt-time-row">
          <div className="dt-col">
            <p className="dt-sublabel">Hora</p>
            <div className="dt-scroll">
              {HOURS.map(h => <button key={h} onClick={() => setSelHour(h)} className={`dt-time-btn${selHour === h ? " dt-t-sel" : ""}`}>{h}</button>)}
            </div>
          </div>
          <div className="dt-col">
            <p className="dt-sublabel">Min</p>
            <div className="dt-scroll">
              {MINUTES.map(m => <button key={m} onClick={() => setSelMin(m)} className={`dt-time-btn${selMin === m ? " dt-t-sel" : ""}`}>{m}</button>)}
            </div>
          </div>
          <div className="dt-col dt-ampm-col">
            <p className="dt-sublabel">AM/PM</p>
            <button onClick={() => setSelAmpm("a.m.")} className={`dt-ampm-btn${selAmpm === "a.m." ? " dt-t-sel" : ""}`}>AM</button>
            <button onClick={() => setSelAmpm("p.m.")} className={`dt-ampm-btn${selAmpm === "p.m." ? " dt-t-sel" : ""}`}>PM</button>
          </div>
        </div>
        <button className="dt-add-btn" onClick={addSlot} disabled={!selectedDay}>
          + Agregar horario{selectedDay ? ` · ${selectedDay} ${MONTH_SHORT[viewMonth]} ${selHour}:${selMin} ${selAmpm}` : ""}
        </button>
      </div>

      {slots.length > 0 && (
        <div className="dt-slots">
          <p className="dt-label">Opciones para la persona señante ({slots.length}/6)</p>
          {slots.map((s, i) => (
            <div key={i} className="dt-slot-item">
              <b>{i + 1}</b>
              <span>📅 {formatSlot(s)}</span>
              <button onClick={() => removeSlot(i)} className="dt-remove">✕</button>
            </div>
          ))}
          <button className="dt-send-btn" onClick={() => { onSendSlots(slots); setSlots([]); setSelectedDay(null) }}>
            Enviar infografía al señante <span>→</span>
          </button>
        </div>
      )}
    </div>
  )
}

function SignerInfographic({ slots, title }: { slots: TimeSlot[]; title: string }) {
  const formatSlot = (s: TimeSlot) => {
    const d = new Date(s.year, s.month, s.day)
    const dayName = ["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"][d.getDay()]
    return `${dayName} ${s.day} ${MONTH_SHORT[s.month]} · ${s.hour}:${s.minute} ${s.ampm}`
  }
  return (
    <div className="signer-infographic">
      <div className="si-header">
        <span className="si-logo">I</span>
        <div>
          <strong>IPS Virrey Solís</strong>
          <em>{title}</em>
        </div>
      </div>
      <p className="si-cta">Muestre el número con su mano</p>
      <div className="si-options">
        {slots.map((s, i) => (
          <div key={i} className="si-option">
            <span className="si-num">{i + 1}</span>
            <span className="si-icon">📅</span>
            <span className="si-text">{formatSlot(s)}</span>
          </div>
        ))}
      </div>
      <p className="si-footer">● Cámara activa · detectando seña</p>
    </div>
  )
}

// ─── Horizontal Signer Infographic ───────────────────────────────────────────

interface InfoOption { icon: string; text: string }

type InfographicKind = "specialty" | "date" | "service" | "generic"

function InfographicCard({ title, options, kind = "generic", pathColor = "#145da0" }: { title: string; options: InfoOption[]; kind?: InfographicKind; pathColor?: string }) {
  const isSpecialty = kind === "specialty"
  const isDate = kind === "date"
  const cols = options.length <= 2 ? options.length : options.length <= 4 ? 2 : options.length <= 6 ? 3 : 2
  return (
    <div className={`inf-card inf-kind-${kind}`} style={{ "--inf-color": pathColor } as React.CSSProperties}>
      {/* Header */}
      <div className="inf-header">
        <div className="inf-logo-row">
          <span className="inf-logo">I</span>
          <div>
            <span className="inf-brand">IPS Virrey Solis</span>
            <span className="inf-tag">{isSpecialty ? "Servicios medicos" : isDate ? "Disponibilidad" : "Solicitud"}</span>
          </div>
          <span className="inf-live">● En vivo</span>
        </div>
        <h3 className="inf-title">{title}</h3>
      </div>
      {/* Instruction */}
      <div className="inf-cta-row">
        <span className="inf-hand">✋</span>
        <span className="inf-cta-text">Haga la <strong>sena del numero</strong> que desea elegir</span>
      </div>
      {/* Options grid */}
      <div className="inf-options" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
        {options.map((opt, i) => (
          <div key={i} className="inf-option">
            <div className="inf-num-badge">{i + 1}</div>
            <span className="inf-opt-icon">{opt.icon}</span>
            <span className="inf-opt-text">{opt.text}</span>
          </div>
        ))}
      </div>
      {/* Footer */}
      <div className="inf-footer">
        <span>Sesion temporal · Sin guardar datos</span>
        <span>InLSC · Atencion inclusiva</span>
      </div>
    </div>
  )
}

// Keep alias for older call sites
function HSignerInfographic({ title, subtitle, options, pathColor }: { title: string; subtitle: string; options: InfoOption[]; pathColor: string }) {
  const kind: InfographicKind = /especialidad/i.test(title) ? "specialty" : /disponibilidad|fecha/i.test(title) ? "date" : /solicitud/i.test(title) ? "service" : "generic"
  return <InfographicCard title={title} options={options} kind={kind} pathColor={pathColor} />
}

// ─── Specialty Table ───────────────────────────────────────────────────────────

function SpecialtyTable({ onSend }: { onSend: (selected: InfoOption[]) => void }) {
  const [selected, setSelected] = useState<InfoOption[]>([])
  const toggle = (s: typeof SPECIALTIES_LIST[0]) => {
    setSelected(prev =>
      prev.find(x => x.text === s.name)
        ? prev.filter(x => x.text !== s.name)
        : [...prev, { icon: s.icon, text: s.name }]
    )
  }
  return (
    <div className="ctx-table spec-table">
      <p className="ctx-table-label">Especialidades — seleccione y luego envie</p>
      <div className="spec-grid">
        {SPECIALTIES_LIST.map((s) => {
          const active = !!selected.find(x => x.text === s.name)
          return (
            <button key={s.name} className={`spec-btn ${active ? "spec-btn-active" : ""}`} onClick={() => toggle(s)}>
              <span className="spec-icon">{s.icon}</span>
              <span>{s.name}</span>
              {active && <span className="spec-check">✓</span>}
            </button>
          )
        })}
      </div>
      {selected.length > 0 && (
        <div className="spec-queue">
          <p className="spec-queue-label">Seleccionadas ({selected.length}):</p>
          <div className="spec-chips">
            {selected.map((s, i) => (
              <span key={i} className="spec-chip">{i + 1}. {s.icon} {s.text}</span>
            ))}
          </div>
          <button className="spec-send-btn" onClick={() => { onSend(selected); setSelected([]) }}>
            Enviar infografia al senante <span>→</span>
          </button>
        </div>
      )}
    </div>
  )
}

// ─── Cita Table ───────────────────────────────────────────────────────────────

function CitaTable({ onSelect }: { onSelect: () => void }) {
  return (
    <div className="ctx-table">
      <p className="ctx-table-label">Citas registradas — haga clic para enviar infografia al senante</p>
      {CITAS_MOCK.map((c, i) => (
        <button key={i} className="cita-row" onClick={onSelect}>
          <span className="cita-num">{i + 1}</span>
          <span className="cita-icon">{c.icon}</span>
          <div className="cita-info">
            <strong>{c.specialty}</strong>
            <em>{c.doctor} · {c.date} · {c.time}</em>
          </div>
          <span className="cita-arrow">→</span>
        </button>
      ))}
    </div>
  )
}

// ─── Path Selector ────────────────────────────────────────────────────────────

function PathSelector({ onSelect }: { onSelect: (p: FlowPath) => void }) {
  return (
    <div className="path-selector">
      <p className="eyebrow">NUEVA ATENCION · TIPO DE TRAMITE</p>
      <p className="path-intro">Seleccione el tipo de tramite que solicita el senante:</p>
      {FLOW_PATHS.map((p) => (
        <button key={p.id} className="path-card" style={{ "--pc": p.color, "--pb": p.bg } as React.CSSProperties} onClick={() => onSelect(p)}>
          <span className="path-card-icon">{p.icon}</span>
          <span className="path-card-name">{p.name}</span>
          <span className="path-card-arrow">→</span>
        </button>
      ))}
    </div>
  )
}

// ─── Progress Bars ────────────────────────────────────────────────────────────

// Short one-word labels for the signer screen
const SIGNER_LABELS: Record<string, string> = {
  "Saludo": "Hola",
  "Solicitud": "Solicitud",
  "Documento": "Doc.",
  "Especialidad": "Espec.",
  "Autorizacion": "Autor.",
  "Disponibilidad": "Fecha",
  "Confirmacion": "Listo",
  "Cancelacion": "Cancel.",
  "Que cita cancelar": "Cita",
  "Cancelada": "Hecho",
  "Despedida": "Adios",
  "Orden medica": "Orden",
  "Valor": "Valor",
  "Solo efectivo": "Pago",
  "Recibo": "Recibo",
  "Sala espera": "Sala",
  "Con gusto": "Listo",
}

function AdminProgress({ steps, current, color }: { steps: FlowStep[]; current: number; color: string }) {
  return (
    <div className="adm-progress">
      {steps.map((s, i) => {
        const state = i < current ? "done" : i === current ? "active" : "pending"
        return (
          <div key={i} className="adm-prog-item">
            {i > 0 && <div className={`adm-prog-line ${i <= current ? "adm-line-done" : ""}`} style={i <= current ? { background: color } : {}} />}
            <div className={`adm-prog-node adm-node-${state}`} style={state !== "pending" ? { background: state === "done" ? color : "#fff", borderColor: color, color: state === "done" ? "#fff" : color } : {}}>
              {state === "done" ? "✓" : i + 1}
            </div>
            <span className={`adm-prog-label ${state === "active" ? "adm-label-active" : ""}`} style={state === "active" ? { color } : {}}>
              {s.label}
            </span>
          </div>
        )
      })}
    </div>
  )
}

function SignerProgress({ steps, current, color }: { steps: FlowStep[]; current: number; color: string }) {
  return (
    <div className="sgn-progress">
      {steps.map((s, i) => {
        const state = i < current ? "done" : i === current ? "active" : "pending"
        const lbl = SIGNER_LABELS[s.label] ?? s.label.split(" ")[0]
        return (
          <div key={i} className="sgn-prog-item">
            {i > 0 && <div className={`sgn-prog-line ${i <= current ? "sgn-line-done" : ""}`} style={i <= current ? { background: color } : {}} />}
            <div className={`sgn-prog-dot sgn-dot-${state}`} style={state !== "pending" ? { background: state === "done" ? color : "#fff", borderColor: color, color: state === "done" ? "#fff" : color } : {}}>
              {state === "done" ? "✓" : i + 1}
            </div>
            <span className={`sgn-prog-label ${state === "active" ? "sgn-label-active" : ""}`} style={state === "active" ? { color } : {}}>
              {lbl}
            </span>
          </div>
        )
      })}
    </div>
  )
}

// Keep old name as alias for compatibility
function FlowProgress({ steps, current, color }: { steps: FlowStep[]; current: number; color: string }) {
  return <AdminProgress steps={steps} current={current} color={color} />
}

// ─── Confidence Bar ───────────────────────────────────────────────────────────

function ConfidenceBar({ target, label, animating }: { target: number; label: string; animating: boolean }) {
  const [pct, setPct] = useState(0)
  useEffect(() => {
    if (!animating) { setPct(target); return }
    setPct(0)
    let current = 0
    const step = () => {
      current += Math.random() * 6 + 2
      if (current >= target) { setPct(target); return }
      setPct(Math.round(current))
      window.setTimeout(step, 80)
    }
    const t = window.setTimeout(step, 120)
    return () => window.clearTimeout(t)
  }, [animating, target])

  const color = pct >= 80 ? "#198754" : pct >= 55 ? "#f4b400" : "#c53d3d"
  const band = pct >= 80 ? "Alta confianza" : pct >= 55 ? "Confianza media" : "Confianza baja"

  return (
    <div className="conf-bar-wrap">
      <div className="conf-bar-header">
        <span className="conf-label">{label}</span>
        <span className="conf-pct" style={{ color }}>{pct} %</span>
      </div>
      <div className="conf-track">
        <div className="conf-fill" style={{ width: `${pct}%`, background: color }} />
        {[25, 50, 75].map(m => <span key={m} className="conf-mark" style={{ left: `${m}%` }} />)}
      </div>
      <div className="conf-footer">
        <span className="conf-band" style={{ color }}>{animating && pct < target ? "Analizando sena…" : band}</span>
        <span className="conf-ticks">25 · 50 · 75 · 100</span>
      </div>
    </div>
  )
}

// ─── Session & Sync Utilities ─────────────────────────────────────────────────

interface SignerViewState {
  phase: "waiting" | "video" | "infographic" | "confirmed" | "farewell"
  videoLabel?: string
  infographic?: {
    title: string
    subtitle: string
    options: InfoOption[]
    pathColor: string
    kind: InfographicKind
  }
  progress?: { steps: FlowStep[]; stepIdx: number; pathColor: string }
  cita?: { fecha: string; specialty: string }
}

// ─── Local Pairing Screen ─────────────────────────────────────────────────────

function LocalPairingScreen({ onContinue }: { onContinue: () => void }) {
  const [urls, setUrls] = useState<string[]>([])
  const [copied, setCopied] = useState("")

  useEffect(() => {
    fetch("/inlsc-host")
      .then(r => r.json())
      .then(({ ips, port }: { ips: string[]; port: number }) => {
        setUrls(ips.map(ip => `http://${ip}:${port}?signer`))
      })
      .catch(() => { setUrls([`${window.location.origin}?signer`]) })
  }, [])

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url).catch(() => {})
    setCopied(url)
    setTimeout(() => setCopied(""), 2200)
  }

  return (
    <div className="qr-screen">
      <div className="qr-screen-header">
        <span className="eyebrow">INLSC · RED LOCAL · SIN INTERNET</span>
        <h2>Conectar tableta del señante</h2>
        <p>En la tableta, abra el navegador e ingrese la dirección de red local. Ambos dispositivos deben estar en la misma red WiFi.</p>
      </div>

      <div className="local-network-card">
        <div className="lnc-icon">📡</div>
        <div>
          <strong>Dirección de la tableta señante</strong>
          <em>Escriba o copie en el navegador de la tableta</em>
        </div>
      </div>

      <div className="local-urls-list">
        {urls.length === 0
          ? <div className="local-url-loading">Obteniendo dirección de red…</div>
          : urls.map(url => (
            <div key={url} className="local-url-row">
              <code className="local-url-text">{url}</code>
              <button className="local-url-copy" onClick={() => copyUrl(url)}>
                {copied === url ? "✓" : "Copiar"}
              </button>
            </div>
          ))
        }
      </div>

      <div className="local-steps">
        <div className="local-step"><span>1</span><p>Ambos en la misma red WiFi institucional</p></div>
        <div className="local-step"><span>2</span><p>Tableta: abrir navegador e ingresar la dirección</p></div>
        <div className="local-step"><span>3</span><p>La vista del señante se activa automáticamente</p></div>
      </div>

      <div className="qr-status qr-waiting">
        <span className="qr-dot" />
        <span>Servidor local activo · Listo para recibir tableta</span>
      </div>
      <button className="dock-action" style={{ marginTop: 10 }} onClick={onContinue}>
        Iniciar atención →
      </button>
    </div>
  )
}

// ─── Signer Tablet View ───────────────────────────────────────────────────────

function SignerWaiting() {
  return (
    <div className="stv-waiting">
      <div className="stv-pulse-rings"><span /><span /><span /></div>
      <div className="stv-logo-big">I</div>
      <strong>IPS Virrey Solís Olaya</strong>
      <p>Esperando al funcionario de recepción…</p>
      <em>Por favor, tenga a la mano su documento de identidad.</em>
    </div>
  )
}

function SignerTabletView() {
  const [state, setState] = useState<SignerViewState>({ phase: "waiting" })
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    const es = new EventSource("/inlsc-events")
    es.onopen = () => setConnected(true)
    es.onmessage = (e: MessageEvent) => {
      try { setState(JSON.parse(e.data) as SignerViewState) } catch (_) {}
    }
    es.onerror = () => setConnected(false)
    return () => es.close()
  }, [])

  const infKind = (title: string): InfographicKind =>
    /especialidad/i.test(title) ? "specialty" : /disponibilidad|fecha/i.test(title) ? "date" : "generic"

  return (
    <div className="stv-root">
      <header className="stv-header">
        <div className="stv-brand">
          <span className="stv-header-logo">I</span>
          <div>
            <strong>InLSC</strong>
            <span>IPS Virrey Solís · Atención en LSC</span>
          </div>
        </div>
        <div className="stv-meta">
          <span className="stv-live" style={{ color: connected ? "#4ade80" : "#f4b400" }}>
            {connected ? "● En atención" : "◌ Conectando…"}
          </span>
          <span className="stv-code">Red local</span>
        </div>
      </header>

      <main className="stv-main">
        {state.phase === "waiting" && <SignerWaiting />}

        {state.phase === "video" && (
          <div className="stv-video-wrap">
            <VideoCard label={state.videoLabel ?? ""} playing setPlaying={() => undefined} />
            <p className="stv-video-label">Video en Lengua de Señas Colombiana</p>
          </div>
        )}

        {state.phase === "infographic" && state.infographic && (
          <div className="stv-inf-wrap">
            <InfographicCard
              title={state.infographic.title}
              options={state.infographic.options}
              kind={infKind(state.infographic.title)}
              pathColor={state.infographic.pathColor}
            />
          </div>
        )}

        {state.phase === "confirmed" && state.cita && (
          <div className="stv-confirmed">
            <div className="stv-check">✓</div>
            <strong className="stv-confirmed-title">Cita Asignada</strong>
            <div className="stv-confirmed-detail">
              <span className="stv-confirmed-icon">📅</span>
              <span className="stv-confirmed-fecha">{state.cita.fecha}</span>
            </div>
            {state.cita.specialty && <span className="stv-confirmed-spec">{state.cita.specialty}</span>}
            <p className="stv-confirmed-note">Que tenga un buen día 👋</p>
          </div>
        )}

        {state.phase === "farewell" && (
          <div className="stv-farewell">
            <VideoCard label="Que tenga un buen dia" playing setPlaying={() => undefined} />
            <p className="stv-farewell-text">Que tenga un buen día · Vuelva pronto</p>
          </div>
        )}
      </main>

      {state.progress && (
        <div className="stv-progress-bar">
          <SignerProgress
            steps={state.progress.steps}
            current={state.progress.stepIdx}
            color={state.progress.pathColor}
          />
        </div>
      )}
    </div>
  )
}

// ─── Admin Dock ───────────────────────────────────────────────────────────────

type DockPhase = "qr" | "greeting" | "detecting" | "confirmed" | "flow" | "farewell"

// Services shown to signer during detection
const SERVICE_OPTIONS: InfoOption[] = [
  { icon: "📋", text: "Asignacion de citas" },
  { icon: "❌", text: "Cancelacion de citas" },
  { icon: "💲", text: "Facturacion de citas" },
]

function CitaConfirmadaScreen({ fecha, specialty }: { fecha: string; specialty: string }) {
  return (
    <div className="cita-confirmada-screen">
      <div className="ccs-check">✓</div>
      <strong className="ccs-title">Cita Asignada</strong>
      <div className="ccs-detail">
        <span className="ccs-icon">📅</span>
        <span className="ccs-fecha">{fecha}</span>
      </div>
      {specialty && <span className="ccs-specialty">{specialty}</span>}
      <p className="ccs-note">Que tenga un buen dia</p>
    </div>
  )
}

function AdminDock() {
  const [phase, setPhase] = useState<DockPhase>("qr")
  const [path, setPath] = useState<FlowPath | null>(null)
  const [detectedIdx, setDetectedIdx] = useState<number | null>(null)
  const [stepIdx, setStepIdx] = useState(2)
  const [infographic, setInfographic] = useState<{ title: string; subtitle: string; options: InfoOption[] } | null>(null)
  const [detectedSign, setDetectedSign] = useState<number | null>(null)
  const [done, setDone] = useState(false)
  const [composerTab, setComposerTab] = useState<"fecha" | "texto">("fecha")
  const [confirmedFecha, setConfirmedFecha] = useState("")
  const [confirmedSpecialty, setConfirmedSpecialty] = useState("")
  const [citaConfirmada, setCitaConfirmada] = useState(false)
  const broadcastRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const step = path ? path.steps[Math.min(stepIdx, path.steps.length - 1)] : null
  const isLastStep = path ? stepIdx >= path.steps.length - 1 : false
  const isSpecialtyStep = step?.kind === "specialty"
  const isDateStep = step?.kind === "date"
  const isCitaStep = step?.kind === "cita"

  useEffect(() => { if (isDateStep) setComposerTab("fecha") }, [isDateStep])

  // After greeting → start detection, simulate result after 3s
  useEffect(() => {
    if (phase !== "detecting") return
    const t = window.setTimeout(() => {
      setDetectedIdx(0) // simulate: asignacion detected
      setPhase("confirmed")
    }, 3000)
    return () => window.clearTimeout(t)
  }, [phase])

  // Simulate sign detection 5s after a flow-infographic appears
  useEffect(() => {
    if (phase !== "flow" || !infographic || detectedSign !== null) return
    const t = window.setTimeout(() => setDetectedSign(1), 5000)
    return () => window.clearTimeout(t)
  }, [phase, infographic, detectedSign])

  // Push signer view state to local SSE server on every relevant change
  useEffect(() => {
    if (phase === "qr") return
    let sv: SignerViewState
    if (phase === "farewell") {
      sv = { phase: "farewell" }
    } else if (phase === "greeting") {
      sv = { phase: "video", videoLabel: "Buen dia" }
    } else if (phase === "detecting" || phase === "confirmed") {
      sv = { phase: "video", videoLabel: "Detectando solicitud..." }
    } else if (phase === "flow" && path) {
      const prog = { steps: path.steps.slice(2), stepIdx: stepIdx - 2, pathColor: path.color }
      if (citaConfirmada) {
        sv = { phase: "confirmed", cita: { fecha: confirmedFecha || "Fecha por confirmar", specialty: confirmedSpecialty }, progress: prog }
      } else if (infographic) {
        const kind: InfographicKind = isSpecialtyStep ? "specialty" : isDateStep ? "date" : "generic"
        sv = { phase: "infographic", infographic: { title: infographic.title, subtitle: infographic.subtitle, options: infographic.options, pathColor: path.color, kind }, progress: prog }
      } else {
        sv = { phase: "video", videoLabel: step?.video ?? "", progress: prog }
      }
    } else {
      sv = { phase: "waiting" }
    }
    if (broadcastRef.current) clearTimeout(broadcastRef.current)
    broadcastRef.current = setTimeout(() => {
      fetch("/inlsc-state", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sv) }).catch(() => {})
    }, 30)
  }, [phase, path, stepIdx, infographic, citaConfirmada, confirmedFecha, confirmedSpecialty, step, isSpecialtyStep, isDateStep])

  const reset = () => { setPhase("greeting"); setPath(null); setDetectedIdx(null); setStepIdx(2); setDone(false); setInfographic(null); setDetectedSign(null); setConfirmedFecha(""); setConfirmedSpecialty(""); setCitaConfirmada(false) }

  const confirmPath = (idx: number) => {
    setPath(FLOW_PATHS[idx])
    setStepIdx(2) // skip Saludo + Solicitud, already handled
    setPhase("flow")
    setInfographic(null)
    setDetectedSign(null)
  }

  const advance = () => {
    if (!path) return
    if (isLastStep) { setPhase("farewell"); return }
    setStepIdx(i => i + 1)
    setInfographic(null)
    setDetectedSign(null)
  }

  const confirmarCita = () => {
    setCitaConfirmada(true)
  }

  const sendSpecialty = useCallback((selected: InfoOption[]) => {
    setInfographic({ title: "Especialidades disponibles", subtitle: "Escoja un numero", options: selected })
    setDetectedSign(null)
  }, [])

  const sendCita = useCallback(() => {
    setInfographic({ title: "Sus citas registradas", subtitle: "Escoja el numero de la cita a cancelar", options: CITAS_MOCK.map((c) => ({ icon: c.icon, text: `${c.specialty} · ${c.date}` })) })
    setDetectedSign(null)
  }, [])

  const handleDateSlots = (slots: TimeSlot[]) => {
    const formatSlot = (s: TimeSlot) => { const d = new Date(s.year, s.month, s.day); return `${["Dom","Lun","Mar","Mie","Jue","Vie","Sab"][d.getDay()]} ${s.day} ${MONTH_SHORT[s.month]} · ${s.hour}:${s.minute} ${s.ampm}` }
    setInfographic({ title: "Disponibilidad", subtitle: "Escoja un numero", options: slots.map((s) => ({ icon: "📅", text: formatSlot(s) })) })
    setDetectedSign(null)
  }

  const confirmSign = () => {
    if (infographic && detectedSign !== null) {
      const opt = infographic.options[detectedSign - 1]
      if (isDateStep) setConfirmedFecha(opt?.text ?? "")
      if (isSpecialtyStep) setConfirmedSpecialty(opt?.text ?? "")
    }
    setInfographic(null)
    setDetectedSign(null)
    advance()
  }

  if (phase === "farewell") return (
    <main className="dock-canvas">
      <aside className="admin-dock">
        <div className="dock-header"><div className="brand-mark">I</div><div><strong>InLSC</strong><span>Finalizando atencion</span></div><i style={{ color: "#198754" }}>●</i></div>
        <div className="signer-preview has-progress" style={{ marginTop: 12 }}>
          <p className="eyebrow">PANTALLA DEL SENANTE</p>
          <VideoCard label="Que tenga un buen dia" playing setPlaying={() => undefined} />
          <p className="preview-hint" style={{ color: "#7dd89e" }}>Video LSC de despedida · Se muestra al senante</p>
        </div>
        <div className="dock-chat" style={{ marginTop: 10 }}>
          <p className="eyebrow">ATENCION FINALIZADA</p>
          <div className="dock-message bot"><small>INLSC · FIN</small>Tramite completado. El video de despedida se esta reproduciendo para el senante.</div>
        </div>
        <div className="done-screen">
          <span className="done-check">✓</span>
          <strong>Tramite completado</strong>
          <p>{path?.name}</p>
          <button className="dock-action" style={{ marginTop: 16 }} onClick={reset}>Nueva atencion →</button>
        </div>
      </aside>
    </main>
  )

  if (done) return (
    <main className="dock-canvas">
      <aside className="admin-dock">
        <div className="dock-header"><div className="brand-mark">I</div><div><strong>InLSC</strong><span>Atencion finalizada</span></div><i>●</i></div>
        <div className="done-screen">
          <span className="done-check">✓</span>
          <strong>Tramite completado</strong>
          <p>{path?.name}</p>
          <button className="dock-action" style={{ marginTop: 16 }} onClick={reset}>Nueva atencion →</button>
        </div>
      </aside>
    </main>
  )

  return (
    <main className="dock-canvas">
      <aside className="admin-dock">

        {/* Header */}
        <div className="dock-header">
          <div className="brand-mark">I</div>
          <div>
            <strong>InLSC</strong>
            <span>{phase === "flow" && path ? path.name : "Nueva atencion · Recepcion"}</span>
          </div>
          <i style={{ color: phase === "detecting" ? "#f4b400" : "#198754" }}>●</i>
        </div>

        {/* ── PHASE: Local Pairing ────────────────────────── */}
        {phase === "qr" && (
          <LocalPairingScreen onContinue={() => setPhase("greeting")} />
        )}

        {/* ── PHASE: Greeting ─────────────────────────────── */}
        {phase === "greeting" && (
          <>
            <div className="signer-preview">
              <p className="eyebrow">PANTALLA DEL SENANTE</p>
              <VideoCard label="Buen dia" playing setPlaying={() => undefined} />
              <p className="preview-muted">Video LSC: saludo de bienvenida</p>
            </div>
            <div className="dock-chat">
              <p className="eyebrow">CHAT DE ATENCION</p>
              <div className="dock-message bot"><small>INLSC · INICIO</small>Enviando saludo LSC. Cuando el senante responda, active la deteccion de sena.</div>
            </div>
            <button className="dock-action" onClick={() => { setPhase("detecting"); setInfographic(null) }}>
              Activar camara · detectar solicitud <span>→</span>
            </button>
          </>
        )}

        {/* ── PHASE: Detecting ────────────────────────────── */}
        {phase === "detecting" && (
          <>
            <div className="signer-preview">
              <p className="eyebrow">PANTALLA DEL SENANTE</p>
              <div className="service-detect-screen">
                <div className="sds-cam-indicator"><span className="sds-live">● Camara activa</span><span className="sds-label">Detectando intencion en LSC</span></div>
                <div className="sds-services">
                  {SERVICE_OPTIONS.map((s, i) => (
                    <div key={i} className="sds-service-chip"><span>{s.icon}</span><span>{s.text}</span></div>
                  ))}
                </div>
                <p className="sds-note">El sistema reconoce la sena libremente — no se requiere numero</p>
              </div>
              <p className="preview-hint">Camara activa · El senante expresa su solicitud en LSC</p>
            </div>
            <div className="dock-chat">
              <p className="eyebrow">CHAT DE ATENCION</p>
              <div className="dock-message bot"><small>INLSC · DETECCION ACTIVA</small>Camara activa. El sistema interpreta la sena de solicitud del senante.</div>
              <div className="detect-scanning">
                <div className="scan-bars"><span /><span /><span /><span /><span /></div>
                <span>Interpretando sena LSC de solicitud…</span>
              </div>
              <ConfidenceBar target={91} label="Precision de interpretacion LSC" animating={true} />
            </div>
          </>
        )}

        {/* ── PHASE: Confirmed ────────────────────────────── */}
        {phase === "confirmed" && detectedIdx !== null && (
          <>
            <div className="signer-preview">
              <p className="eyebrow">PANTALLA DEL SENANTE</p>
              <div className="service-detect-screen confirmed">
                <div className="sds-cam-indicator"><span className="sds-live">● Camara activa</span><span className="sds-label">Sena LSC interpretada</span></div>
                <div className="sds-services">
                  {SERVICE_OPTIONS.map((s, i) => (
                    <div key={i} className={`sds-service-chip ${i === detectedIdx ? "sds-chip-match" : ""}`}><span>{s.icon}</span><span>{s.text}</span>{i === detectedIdx && <span className="sds-match-dot">✓</span>}</div>
                  ))}
                </div>
                <p className="sds-note">Solicitud reconocida por sena LSC libre</p>
              </div>
              <p className="preview-hint">Sena interpretada · Confirme el tramite detectado</p>
            </div>
            <div className="dock-chat">
              <p className="eyebrow">SENA LSC INTERPRETADA</p>
              <div className="detected-service-card" style={{ borderColor: FLOW_PATHS[detectedIdx].color }}>
                <span className="dsc-icon">{FLOW_PATHS[detectedIdx].icon}</span>
                <div>
                  <strong>{FLOW_PATHS[detectedIdx].name}</strong>
                  <em>Sena LSC reconocida · Interpretacion automatica</em>
                </div>
              </div>
              <ConfidenceBar target={91} label="Precision de interpretacion LSC" animating={false} />
              <button className="retry-capture-btn" onClick={() => { setPhase("detecting"); setDetectedIdx(null) }}>
                ↺ Volver a captar sena — resultado incierto?
              </button>
              <p className="detect-confirm-label">O confirme el tramite detectado:</p>
              <div className="detect-options">
                {FLOW_PATHS.map((p, i) => (
                  <button key={p.id} className={`detect-opt ${i === detectedIdx ? "detect-opt-active" : ""}`} style={{ "--dc": p.color } as React.CSSProperties} onClick={() => setDetectedIdx(i)}>
                    <span>{p.icon}</span><span>{p.name}</span>
                    {i === detectedIdx && <span className="detect-check">✓</span>}
                  </button>
                ))}
              </div>
              <button className="dock-action" style={{ marginTop: 10 }} onClick={() => confirmPath(detectedIdx)}>
                Confirmar: {FLOW_PATHS[detectedIdx].name} <span>→</span>
              </button>
            </div>
          </>
        )}

        {/* ── PHASE: Flow ─────────────────────────────────── */}
        {phase === "flow" && path && (
          <>
            <FlowProgress steps={path.steps.slice(2)} current={stepIdx - 2} color={path.color} />

            <div className="signer-preview has-progress">
              <p className="eyebrow">PANTALLA DEL SENANTE</p>
              <SignerProgress steps={path.steps.slice(2)} current={stepIdx - 2} color={path.color} />
              {citaConfirmada
                ? <CitaConfirmadaScreen fecha={confirmedFecha || "Fecha por confirmar"} specialty={confirmedSpecialty} />
                : infographic
                  ? <HSignerInfographic title={infographic.title} subtitle={infographic.subtitle} options={infographic.options} pathColor={path.color} />
                  : <VideoCard label={step?.video ?? ""} playing setPlaying={() => undefined} />
              }
              {citaConfirmada
                ? <p className="preview-hint" style={{ color: "#7dd89e" }}>Cita confirmada · El senante ve la confirmacion</p>
                : infographic
                  ? <p className="preview-hint">Infografia activa · Camara detectando numero</p>
                  : <p className="preview-muted">Video LSC: {step?.video}</p>
              }
            </div>

            {/* Number sign detection — only for specialty/date steps */}
            {detectedSign !== null && infographic && (isSpecialtyStep || isDateStep) && (
              <div className="detected-sign-banner">
                <span className="ds-hand">✋</span>
                <div>
                  <strong>Numero {detectedSign} detectado</strong>
                  <span>{infographic.options[detectedSign - 1]?.text ?? ""}</span>
                </div>
                <div className="dsb-actions">
                  <button className="ds-confirm" onClick={confirmSign}>Confirmar →</button>
                  <button className="ds-retry" onClick={() => { setDetectedSign(null) }} title="Resultado incierto? Volver a captar">↺ Recaptar</button>
                </div>
              </div>
            )}

            {/* ── Tables BEFORE signer preview updates ── */}
            {isSpecialtyStep && !infographic && (
              <div className="dock-chat">
                <p className="eyebrow">CHAT DE ATENCION</p>
                <div className="dock-message bot"><small>INLSC · PASO {stepIdx - 1} DE {path.steps.length - 2}</small>{step?.message}</div>
                <SpecialtyTable onSend={(sel) => sendSpecialty(sel)} />
              </div>
            )}

            {isCitaStep && !infographic && (
              <div className="dock-chat">
                <p className="eyebrow">CHAT DE ATENCION</p>
                <div className="dock-message bot"><small>INLSC · PASO {stepIdx - 1} DE {path.steps.length - 2}</small>{step?.message}</div>
                <CitaTable onSelect={() => sendCita()} />
              </div>
            )}

            {isDateStep && !infographic && (
              <div className="dock-chat">
                <p className="eyebrow">CHAT DE ATENCION</p>
                <div className="dock-message bot"><small>INLSC · PASO {stepIdx - 1} DE {path.steps.length - 2}</small>{step?.message}</div>
                <div className="disponibilidad-hint"><span>📅</span><div><strong>Disponibilidad</strong><em>Seleccione horarios y envielos como infografia al senante.</em></div></div>
                <div className="composer-tabs">
                  <button onClick={() => setComposerTab("fecha")} className={composerTab === "fecha" ? "tab-active" : ""}>📅 Fecha y hora</button>
                  <button onClick={() => setComposerTab("texto")} className={composerTab === "texto" ? "tab-active" : ""}>✏️ Texto</button>
                </div>
                {composerTab === "fecha"
                  ? <DateTimePicker onSendSlots={handleDateSlots} />
                  : <div className="chat-composer"><textarea onChange={() => {}} placeholder="Escriba horarios disponibles…" /><button>Enviar</button></div>
                }
              </div>
            )}

            {/* Chat with confidence bar — shown after infographic is sent */}
            {infographic && (isSpecialtyStep || isDateStep || isCitaStep) && (
              <div className="dock-chat">
                <p className="eyebrow">CHAT DE ATENCION</p>
                <div className="dock-message bot"><small>INLSC · PASO {stepIdx - 1} DE {path.steps.length - 2}</small>Infografia enviada al senante · Esperando sena numerica…</div>
                {detectedSign === null
                  ? <ConfidenceBar target={0} label="Esperando sena numerica…" animating={false} />
                  : <ConfidenceBar target={94} label="Precision deteccion numero" animating={true} />
                }
              </div>
            )}

            {/* Chat for plain video steps */}
            {step?.kind === "video" && (
              <div className="dock-chat">
                <p className="eyebrow">CHAT DE ATENCION</p>
                <div className="dock-message bot"><small>INLSC · PASO {stepIdx - 1} DE {path.steps.length - 2}</small>{step?.message}</div>
              </div>
            )}

            {/* Confirmar cita button — only last step of asignacion, before finalizar */}
            {isLastStep && path.id === "asignacion" && !citaConfirmada && (
              <button className="confirm-cita-btn" onClick={confirmarCita}>
                ✓ Confirmar cita — mostrar al senante <span>→</span>
              </button>
            )}

            {/* Action button — only for video steps */}
            {step?.kind === "video" && (
              <button className="dock-action" style={{ background: path.color }} onClick={advance}>
                {isLastStep ? "Finalizar atencion — reproducir despedida" : step.action} <span>→</span>
              </button>
            )}

            <button className="dock-reset" onClick={reset}>
              ← Cambiar tramite
            </button>
          </>
        )}

        <p className="dock-note">El sistema interno de la IPS queda libre en el resto de la pantalla.</p>
      </aside>
    </main>
  )
}

export default function App() {
  const params = new URLSearchParams(window.location.search)
  if (params.has("signer")) return <SignerTabletView />
  return <AdminApp />
}

function AdminApp() {
  const [launched, setLaunched] = useState(false)
  const [screen, setScreen] = useState<Screen>("home")
  const [menuOpen, setMenuOpen] = useState(true)
  const [camera, setCamera] = useState(true)
  const [error, setError] = useState(false)
  const [caseSaved, setCaseSaved] = useState(false)
  const [recognitionReady, setRecognitionReady] = useState(false)
  const [chosen, setChosen] = useState({ specialty: "Medicina general", location: "Sede Centro", date: "18 de septiembre", time: "9:30 a. m." })
  const pageTitle: Record<Screen, string> = { home: "Nueva atención", specialty: "Asignar una cita", location: "Seleccione la sede", date: "Seleccione una fecha", time: "Seleccione un horario", confirm: "Confirme su solicitud", success: "Cita confirmada", cancel: "Cancelar cita", appointment: "Mi próxima cita", staff: "Atención con funcionario" }
  const choose = (key: keyof typeof chosen, value: string, next: Screen) => { setChosen({ ...chosen, [key]: value }); setScreen(next) }
  if (!launched) return <FloatingLauncher onStart={() => setLaunched(true)} />
  if (!recognitionReady) return <IntakeSession onDetected={() => setRecognitionReady(true)} />
  if (recognitionReady) return <AdminDock />
  return <main className="app-shell">
    <aside className={`sidebar ${menuOpen ? "" : "collapsed"}`}><div className="brand"><div className="brand-mark">I</div>{menuOpen && <div><strong>InLSC</strong><small>Asistente en LSC salud</small></div>}<button onClick={() => setMenuOpen(!menuOpen)} aria-label="Contraer menú">≪</button></div>
      <nav>{navItems.map((item, i) => <button className={i === 0 ? "nav-active" : ""} key={item} onClick={() => i === 0 && setScreen("home")}><Icon>{["⌂", "＋", "▣", "⚙"][i]}</Icon>{menuOpen && item}</button>)}</nav>
      <div className="sidebar-bottom"><button><Icon>?</Icon>{menuOpen && "Ayuda y accesibilidad"}</button><button><Icon>↪</Icon>{menuOpen && "Cerrar sesión"}</button></div>
    </aside>
    <div className="workspace"><header><div className="header-title"><span className="crumb">Inicio / {pageTitle[screen]}</span><h1>{pageTitle[screen]}</h1></div><div className="header-actions"><span className="system-ok">● Sistema conectado</span><button className="header-icon">?</button><button className="profile">R<span>Recepción</span></button></div></header>
      <div className="content"><section className="main-column"><Stepper screen={screen} />
        {screen === "home" && <><div className="welcome"><p className="eyebrow">ATENCIÓN EN LENGUA DE SEÑAS COLOMBIANA</p><h2>¿Qué trámite desea realizar?</h2><p>La persona puede realizar una seña o elegir una opción. Estamos listos para acompañar cada paso.</p></div><div className="camera-section"><div className="camera-heading"><div><h2>Cámara de reconocimiento LSC</h2><p>Reconocimiento de intención en tiempo real</p></div><span className={camera ? "online" : "status-muted"}>{camera ? "● Cámara activa" : "Cámara pausada"}</span></div><VideoCard label="vista de cámara" camera /><div className="camera-buttons"><Button kind="secondary" onClick={() => setCamera(!camera)}><Icon>{camera ? "Ⅱ" : "▶"}</Icon>{camera ? "Pausar cámara" : "Activar cámara"}</Button><Button kind="secondary"><Icon>⟳</Icon>Cambiar cámara</Button><Button kind="quiet" onClick={() => setError(!error)}>Repetir expresión</Button></div></div>
          <div className={`interpretation ${error ? "interpret-error" : ""}`}>{error ? <><div className="error-symbol">!</div><div><strong>No logramos comprender la expresión</strong><p>Intente realizar la seña otra vez o seleccione una opción.</p></div><Button onClick={() => setError(false)}>Repetir</Button></> : !recognitionReady ? <><div className="intent-icon waiting-icon">◌</div><div className="intent-copy"><span>Reconocimiento LSC activo</span><strong>Esperando una expresión</strong><p>Cuando se detecte el servicio, se abrirá el chat de atención.</p></div><Button onClick={() => setRecognitionReady(true)}>Detectar servicio</Button></> : <><div className="intent-icon">✓</div><div className="intent-copy"><span>Interpretación detectada</span><strong>Asignar cita</strong><p>"Deseo solicitar una cita médica"</p></div><div className="confidence"><span>94 % de confianza</span><div><i /></div></div><Button onClick={() => setScreen("specialty")}>Confirmar</Button><Button kind="quiet" onClick={() => setError(true)}>No es correcto</Button></>}</div></>}
        {screen === "specialty" && <Choice title="Seleccione la especialidad médica que necesita." subtitle="Puede usar las señas o seleccionar una opción." items={specialties} onChoose={(v) => choose("specialty", v, "location")} />}
        {screen === "location" && <Choice title="Seleccione la sede de atención." subtitle="Las sedes disponibles se muestran a continuación." items={["Sede Centro · Carrera 7 # 34-22", "Sede Olaya · Calle 22 Sur # 15-08", "Sede Norte · Autopista Norte # 182-43", "Ver todas las sedes"]} onChoose={(v) => choose("location", v, "date")} />}
        {screen === "date" && <Calendar onChoose={(v) => choose("date", v, "time")} />}
        {screen === "time" && <Choice title="Seleccione un horario disponible." subtitle="Medicina general · Sede Centro · miércoles 18 de septiembre" items={times} onChoose={(v) => choose("time", v, "confirm")} compact />}
        {screen === "confirm" && <div className="process-card confirmation"><p className="eyebrow">REVISE LA INFORMACIÓN</p><h2>Su solicitud de cita</h2><div className="summary-grid"><Summary label="Especialidad" value={chosen.specialty} /><Summary label="Sede" value={chosen.location} /><Summary label="Fecha" value={chosen.date} /><Summary label="Hora" value={chosen.time} /></div><div className="pending">◷ Pendiente de confirmación</div><div className="actions-row"><Button onClick={() => setScreen("success")}>✓ Confirmar cita</Button><Button kind="secondary" onClick={() => setScreen("specialty")}>Cambiar información</Button><Button kind="quiet" onClick={() => setScreen("home")}>Cancelar proceso</Button></div></div>}
        {screen === "success" && <div className="success-card"><div className="success-check">✓</div><p className="eyebrow">PROCESO COMPLETADO</p><h2>Su cita fue confirmada</h2><p>Recibirá un recordatorio antes de su atención.</p><div className="appointment-number">NÚMERO DE CITA <strong>VS-2026-004821</strong></div><div className="actions-row"><Button>Ver comprobante</Button><Button kind="secondary">⇩ Descargar comprobante</Button><Button kind="quiet" onClick={() => setScreen("home")}>Iniciar nueva atención</Button></div></div>}
        {screen === "cancel" && <div className="process-card"><p className="eyebrow">CITA PROGRAMADA</p><h2>¿Desea cancelar esta cita?</h2><div className="appointment-card"><div><span>Medicina general</span><strong>Dr. Santiago Rojas</strong></div><div><span>Fecha y hora</span><strong>18 sep · 9:30 a. m.</strong></div><div><span>Sede</span><strong>Centro</strong></div><b>Confirmada</b></div><p className="alert-text">Esta acción liberará el horario seleccionado.</p><div className="actions-row"><Button kind="danger" onClick={() => setScreen("home")}>Cancelar cita</Button><Button kind="secondary" onClick={() => setScreen("home")}>Mantener cita</Button><Button kind="quiet" onClick={() => setScreen("staff")}>Solicitar ayuda</Button></div></div>}
        {screen === "appointment" && <div className="process-card"><p className="eyebrow">PRÓXIMA ATENCIÓN</p><h2>Su próxima cita</h2><div className="appointment-card large"><div><span>Especialidad</span><strong>Medicina general</strong></div><div><span>Fecha y hora</span><strong>Miércoles 18 · 9:30 a. m.</strong></div><div><span>Sede</span><strong>Centro · Consultorio 204</strong></div><b>Confirmada</b></div><div className="actions-row"><Button kind="secondary">Modificar cita</Button><Button kind="danger" onClick={() => setScreen("cancel")}>Cancelar cita</Button><Button kind="quiet">Ver indicaciones</Button></div></div>}
        {screen === "staff" && <div className="staff-panel"><div className="staff-alert"><strong>Se requiere validación del funcionario</strong><span>La intención necesita acompañamiento humano.</span></div><h2>Atención actual</h2><div className="active-case"><div className="avatar">LM</div><div><strong>Laura Martínez</strong><p>Solicitud de cita · Confianza 64 %</p></div><span>En espera</span><Button>Tomar atención</Button></div><div className="privacy-panel"><strong>Sesión temporal y privada</strong><p>La información se elimina al finalizar. Guarde una nota solo si es necesario para la atención.</p><Button kind={caseSaved ? "secondary" : "primary"} onClick={() => setCaseSaved(!caseSaved)}>{caseSaved ? "✓ Nota guardada para esta atención" : "Guardar nota de esta atención"}</Button></div><div className="staff-actions"><Button kind="secondary">Enviar mensaje</Button><Button kind="quiet" onClick={() => setScreen("home")}>Finalizar atención y eliminar sesión</Button></div></div>}
        </section><Conversation screen={screen} setScreen={setScreen} /></div>
    </div>
  </main>
}

function Choice({ title, subtitle, items, onChoose, compact }: { title: string; subtitle: string; items: string[]; onChoose: (v: string) => void; compact?: boolean }) { return <div className={`process-card choice-card ${compact ? "compact" : ""}`}><p className="eyebrow">ASIGNACIÓN DE CITA</p><h2>{title}</h2><p className="intro">{subtitle}</p><div className="choice-grid">{items.map((item, i) => <button key={item} onClick={() => onChoose(item)}><span className="choice-number">{String(i + 1).padStart(2, "0")}</span><strong>{item}</strong><span>→</span></button>)}</div></div> }
function Summary({ label, value }: { label: string; value: string }) { return <div className="summary"><span>{label}</span><strong>{value}</strong></div> }
function Calendar({ onChoose }: { onChoose: (v: string) => void }) { const days = ["L", "M", "M", "J", "V", "S", "D"]; return <div className="process-card calendar"><p className="eyebrow">ASIGNACIÓN DE CITA</p><h2>Seleccione una fecha disponible.</h2><p className="intro">Septiembre 2026 · Sede Centro</p><div className="calendar-head">{days.map((d, i) => <span key={i}>{d}</span>)}</div><div className="calendar-grid">{Array.from({ length: 30 }, (_, i) => { const d = i + 1; const available = [4, 7, 9, 11, 14, 16, 18, 21, 23, 25, 28].includes(d); return <button disabled={!available} className={d === 18 ? "selected-date" : available ? "available-date" : ""} onClick={() => onChoose(`${d} de septiembre`)} key={d}>{d}{available && <small>Disponible</small>}</button> })}</div><div className="legend"><span><i className="available-dot" /> Disponible</span><span><i className="unavailable-dot" /> No disponible</span><span><i className="selected-dot" /> Fecha seleccionada</span></div></div> }
