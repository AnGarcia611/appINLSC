Diseña una aplicación de escritorio llamada “Señas Salud”, un asistente inteligente multimodal para facilitar la atención administrativa de personas sordas usuarias de la Lengua de Señas Colombiana (LSC) en una IPS.

La aplicación debe tener una interfaz profesional, accesible, clara y moderna. No debe parecer una aplicación médica para diagnóstico; debe estar enfocada únicamente en trámites administrativos.

## Objetivo principal

Crear un prototipo navegable de alta fidelidad que simule la interacción entre:

1. Una persona sorda que se comunica mediante LSC.
2. El asistente inteligente que reconoce la intención.
3. El funcionario administrativo que puede supervisar o continuar la atención.

El sistema debe permitir simular los siguientes procesos:

- Asignación de citas.
- Cancelación de citas.
- Consulta de citas.
- Consulta de especialidad médica.
- Consulta de disponibilidad.
- Confirmación de datos.
- Información de facturación o pagos.
- Solicitud de ayuda de un funcionario.

## Estilo visual

Utiliza un diseño accesible y de alto contraste:

- Fondo principal: #F6F8FB.
- Azul institucional: #145DA0.
- Azul claro: #DCEEFF.
- Verde de confirmación: #198754.
- Amarillo de advertencia: #F4B400.
- Rojo de error: #D64545.
- Texto principal: #1F2937.
- Bordes suaves y esquinas redondeadas de 12 a 16 px.
- Tipografía sans serif clara, como Inter, Arial o similar.
- Botones grandes, con áreas táctiles amplias.
- No utilizar texto pequeño.
- Usar iconos simples y comprensibles.
- Mantener una jerarquía visual clara.
- Incluir etiquetas textuales junto a los iconos.
- No depender únicamente del color para comunicar estados.

## Ventana principal

Crea una ventana de escritorio de aproximadamente 1440 x 900 px.

La pantalla debe dividirse en tres zonas:

### 1. Barra superior

Incluye:

- Logotipo textual “Señas Salud”.
- Texto: “Asistente administrativo en LSC”.
- Indicador de conexión: “Sistema conectado”.
- Nombre del usuario administrativo: “Recepción”.
- Botón de configuración.
- Botón para minimizar u ocultar el asistente.
- Botón de ayuda.

### 2. Panel izquierdo: cámara y reconocimiento

Crear una tarjeta grande titulada:

“Cámara de reconocimiento LSC”

Dentro de la tarjeta incluir:

- Área de video simulada con una persona realizando señas.
- Utiliza un placeholder visual atractivo si no existe un video real.
- El placeholder debe mostrar un ícono de cámara o video.
- Texto: “Vista previa de la cámara”.
- Marco visual que indique el área recomendada para realizar las señas.
- Indicador de estado: “Cámara activa”.
- Botón “Pausar cámara”.
- Botón “Cambiar cámara”.
- Botón “Repetir expresión”.

Debajo del video incluir una sección llamada:

“Interpretación detectada”

Mostrar:

- Intención identificada: “Asignar cita”.
- Nivel de confianza: “94 %”.
- Barra visual de confianza.
- Texto interpretado: “Deseo solicitar una cita médica”.
- Botón “Confirmar”.
- Botón “No es correcto”.

Cuando el sistema esté procesando, mostrar temporalmente:

- Animación o indicador de carga.
- Texto: “Reconociendo expresión en LSC…”.

Cuando no comprenda la expresión, mostrar:

- Estado de error amable.
- Texto: “No logramos comprender la expresión”.
- Botón “Repetir”.
- Botón “Mostrar opciones”.
- Botón “Solicitar apoyo administrativo”.

### 3. Panel derecho: asistente conversacional

Crear una tarjeta titulada:

“Asistente de atención”

Mostrar un historial de conversación con burbujas diferenciadas:

- Mensajes del usuario.
- Mensajes del asistente.
- Mensajes del sistema.
- Mensajes del funcionario.

Cada mensaje debe mostrar:

- Texto breve.
- Hora.
- Estado de interpretación.
- Icono que indique si el mensaje fue reconocido correctamente.

En la parte superior del panel incluir un reproductor de video LSC del asistente:

- Área de video de aproximadamente 360 x 220 px.
- Placeholder con una persona intérprete.
- Etiqueta: “Respuesta del asistente en LSC”.
- Controles: reproducir, pausar, repetir y subtítulos.
- Texto debajo: “Seleccione una opción para continuar”.

Debajo del historial incluir botones grandes:

- “Asignar una cita”
- “Cancelar una cita”
- “Consultar mi cita”
- “Consultar especialidad”
- “Consultar horarios”
- “Información de pagos”
- “Hablar con un funcionario”

## Menú lateral opcional

Crear un menú lateral colapsable con las siguientes opciones:

- Inicio.
- Nueva atención.
- Historial de atenciones.
- Citas.
- Usuarios.
- Configuración.
- Ayuda y accesibilidad.
- Cerrar sesión.

El menú debe incluir iconos y textos.

## Flujo 1: asignación de cita

Crear un flujo navegable con las siguientes pantallas o estados:

### Estado 1: inicio

Mostrar el mensaje en el video LSC:

“Bienvenido. ¿Qué trámite desea realizar?”

Mostrar botones:

- Asignar una cita.
- Cancelar una cita.
- Consultar una cita.
- Solicitar ayuda.

### Estado 2: especialidad

Mostrar el video del asistente en LSC y el texto:

“Seleccione la especialidad médica que necesita.”

Mostrar botones grandes:

- Medicina general.
- Odontología.
- Pediatría.
- Ginecología.
- Medicina interna.
- Otra especialidad.

### Estado 3: sede

Mostrar:

“Seleccione la sede de atención.”

Botones:

- Sede Olaya.
- Sede Centro.
- Sede Norte.
- Ver todas las sedes.

### Estado 4: fecha

Mostrar:

“Seleccione una fecha disponible.”

Crear un calendario visual con fechas disponibles y no disponibles. Usar colores, pero acompañarlos con etiquetas:

- Disponible.
- No disponible.
- Fecha seleccionada.

### Estado 5: horario

Mostrar tarjetas con horarios:

- 8:00 a. m.
- 9:30 a. m.
- 11:00 a. m.
- 2:00 p. m.
- 3:30 p. m.

Cada tarjeta debe indicar disponibilidad.

### Estado 6: confirmación

Mostrar un resumen:

- Especialidad.
- Sede.
- Fecha.
- Hora.
- Estado: pendiente de confirmación.

Mostrar botones:

- “Confirmar cita”.
- “Cambiar información”.
- “Cancelar proceso”.

### Estado 7: cita confirmada

Mostrar un estado exitoso con:

- Icono de confirmación.
- Texto: “Su cita fue confirmada”.
- Número de cita: “VS-2026-004821”.
- Botón “Ver comprobante”.
- Botón “Descargar comprobante”.
- Botón “Iniciar nueva atención”.

El video del asistente debe mostrar una respuesta simulada en LSC.

## Flujo 2: cancelación de cita

Crear una pantalla en la que el usuario pueda seleccionar una cita existente.

Mostrar una tarjeta de cita con:

- Especialidad.
- Profesional.
- Fecha.
- Hora.
- Sede.
- Estado de la cita.

Incluir botones:

- “Cancelar cita”.
- “Mantener cita”.
- “Solicitar ayuda”.

Al seleccionar cancelar, mostrar un cuadro de confirmación:

“¿Está seguro de que desea cancelar esta cita?”

Botones:

- Confirmar cancelación.
- Regresar.

Después de confirmar, mostrar:

“Su cita fue cancelada correctamente”.

## Flujo 3: consulta de cita

Crear una pantalla que muestre:

- Próxima cita.
- Fecha.
- Hora.
- Especialidad.
- Sede.
- Estado.

Incluir botones:

- “Modificar cita”.
- “Cancelar cita”.
- “Ver indicaciones”.
- “Volver al inicio”.

## Flujo 4: funcionario administrativo

Crear un panel adicional para el funcionario con:

- Lista de atenciones activas.
- Nombre o identificador del usuario.
- Intención detectada.
- Nivel de confianza.
- Estado de la conversación.
- Botón “Tomar atención”.
- Botón “Enviar mensaje”.
- Botón “Finalizar atención”.

Mostrar una alerta cuando el sistema tenga baja confianza:

“Se requiere validación del funcionario. La intención no fue reconocida con suficiente confianza.”

## Estados del sistema

Crear componentes o variantes para los siguientes estados:

1. Sistema listo.
2. Cámara activa.
3. Reconociendo expresión.
4. Intención identificada.
5. Esperando confirmación.
6. Expresión no comprendida.
7. Error de conexión.
8. Atención transferida al funcionario.
9. Proceso completado.

Cada estado debe tener:

- Indicador visual.
- Texto explicativo.
- Acción recomendada.
- Botón de recuperación cuando sea necesario.

## Componentes reutilizables

Crear componentes reutilizables con variantes para:

- Botones principales.
- Botones secundarios.
- Botones de error.
- Botones de confirmación.
- Tarjetas de proceso.
- Burbujas de conversación.
- Reproductor de video LSC.
- Indicadores de confianza.
- Alertas.
- Calendario.
- Selector de horarios.
- Tarjetas de citas.
- Barra de estado.
- Modal de confirmación.
- Menú lateral.
- Encabezado de aplicación.

## Simulación de videos

Como se trata de un prototipo, no es necesario utilizar videos reales. Para cada reproductor de video, utiliza un placeholder visual con:

- Imagen o ilustración de una persona intérprete realizando LSC.
- Fondo neutro.
- Etiqueta de la acción, por ejemplo:
  “Video LSC: seleccionar especialidad”
  “Video LSC: cita confirmada”
  “Video LSC: no se comprendió la expresión”.

Si es posible, simula la reproducción mediante estados visuales:

- Video detenido.
- Video reproduciendo.
- Video pausado.
- Video finalizado.

Incluye botones de reproducir, pausar y repetir.

## Prototipo interactivo

Configura las interacciones principales:

- Al seleccionar “Asignar una cita”, navegar al flujo de asignación.
- Al seleccionar una especialidad, avanzar a selección de sede.
- Al seleccionar una sede, avanzar al calendario.
- Al seleccionar una fecha, avanzar a los horarios.
- Al seleccionar un horario, avanzar a la confirmación.
- Al seleccionar “Confirmar cita”, mostrar la pantalla de cita confirmada.
- Al seleccionar “Cancelar una cita”, navegar al flujo de cancelación.
- Al seleccionar “Hablar con un funcionario”, mostrar el panel de transferencia.
- Al seleccionar “No es correcto”, mostrar el estado de repetición.
- Al seleccionar “Mostrar opciones”, mostrar las intenciones disponibles.
- Al seleccionar “Repetir video”, cambiar el estado del reproductor.
- Al seleccionar “Ocultar asistente”, minimizar el panel sin cerrar la aplicación.

Usa animaciones suaves, transiciones tipo Smart Animate y cambios de estado claros.

## Accesibilidad

La interfaz debe cumplir estas reglas:

- Contraste suficiente entre texto y fondo.
- Texto mínimo de 16 px.
- Botones grandes y fáciles de seleccionar.
- Mensajes simples y directos.
- Uso de iconos acompañados por texto.
- Subtítulos disponibles en todos los videos.
- No utilizar sonidos como única forma de notificación.
- Mostrar claramente cuándo el sistema está escuchando, procesando o esperando.
- Incluir una alternativa mediante botones cuando el reconocimiento visual falle.
- Permitir transferir la atención a un funcionario en cualquier momento.

## Resultado esperado

Genera un prototipo completo de alta fidelidad en español, con:

- Pantalla principal.
- Flujo de asignación de citas.
- Flujo de cancelación.
- Flujo de consulta.
- Pantalla de error de reconocimiento.
- Pantalla de transferencia a funcionario.
- Panel administrativo.
- Componentes reutilizables.
- Estados visuales del asistente.
- Placeholders para videos LSC.
- Navegación funcional entre las pantallas.
